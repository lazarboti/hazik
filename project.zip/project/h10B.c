#include <stdio.h>
#include "prog1.h"
#include <string.h>
#include <stdlib.h>
#include <time.h>

#define SIZE 1000

int main()
{
    string fajlnev = "numbers.txt";
    char sor[SIZE];
    string Ssor;
    int osszeg = 0;
    int *szamok= NULL;
    int elemszam = 0;
    FILE *file = fopen(fajlnev, "r");
    if (file == NULL)
    {
        printf("Hiba! A fájlt nem sikerült megnyitni!\n");
        return 1;
    }

    while (fgets(sor, SIZE, file) != NULL)
    {
        sor[strlen(sor) - 1] = '\0';
        Ssor = sor;
        szamok = realloc(szamok, (elemszam + 1) * sizeof(int));
        szamok[elemszam] = atoi(Ssor);
        elemszam++;
    }

    fclose(file);
    double atlag=0;
    for (int i = 0; i < elemszam; i++)
    {
        atlag = atlag+szamok[i];
    }
    printf("Az átlag: %.2f\n",atlag/elemszam);

    free(szamok);
    return 0;
}
