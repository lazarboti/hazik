#include <stdio.h>
#include <stdlib.h>

typedef struct {
    int *elems;
    int length;
    int capacity;

} DynArray;

DynArray * da_create()
{
    DynArray *result =malloc(sizeof(DynArray));
    if (result == NULL)
    {
        printf("Nem tudtunk tárterületet lefoglalni\n");
        return 1;
    }

    int initial_capacity = 2;

    result-> elems = malloc(initial_capacity*sizeof(int));
    if (result->elems == NULL)
    {
        printf("Nem tudtunk tárterületet lefoglalni\n");
        return 1;
    }
    result->length = 0;
    result->capacity= initial_capacity;

    return result;

}
void da_clear(DynArray*self)
{
    free(self->elems);
    free(self);
}



int main()
{
    DynArray *li = da_create();
    da_append(li, 1);
    da_append(li, 2);
    da_append(li, 3);

    for (int i = 0; i < li->length; i++)
    {
        printf("%d ", li->elems[i]);
    }
    puts("");
    da_clear(li);
    li =NULL;
    return 0;
}