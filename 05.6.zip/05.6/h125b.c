#include <stdio.h>
#include "prog1.h"
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

 #define SIZE 1000
 #define Nhossz 100

int main()
{

    string nev;
    int kor;
    string szak;
    char *p;

    int elemszam =0;
    string fajlnev = "nevek.csv";
    char sor[SIZE];
    FILE *file =fopen(fajlnev,"r");
    if (file == NULL)
    {
        printf("ERROR! A fájlt nem sikerült megnyitni!");
        return 1;
    }
     
    while(fgets(sor, SIZE,file)!=NULL)
    {
        sor[strlen(sor)-1]= '\0';
        p=strtok(sor,",");
        nev =p;
        p=strtok(NULL,",");
        kor =atoi(p);
        p= strtok(NULL,",");
        szak = p;
        for (int i = 0; i < strlen(szak); i++)
        {
            szak[i] =toupper(szak[i]);
        }
        
        //szak =toupper(szak);
        if (strcmp(szak,"PTI")==0)
        {
            printf("%s\n",nev);
        }
        
    }
    fclose(file);

    return 0;
}