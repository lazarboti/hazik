#include <stdio.h>
#include "prog1.h"
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

int main()
{

    int szam1 = 1;
    int szam2 = 2;
    int szam3 = 3;
    int szam4 = 4;
    int szam5 = 5;
    int szam6 = 6;

    for (int a = 1; a < 90; a++)
    {
        for (int b = 2; b < 90; b++)
        {
            for (int c = 3; c < 90; c++)
            {
                for (int d = 4; d < 90; d++)
                {
                    for (int e =  5; e < 90; e++)
                    {
                        for (int f = 0; f < 90; f++)
                        {
                            if (a+b+c+d+e+f==90 && a*b*c*d*e*f==996300)
                            {
                                printf("%d, %d, %d, %d, %d, %d",a,b,c,d,e,f);
                                return 0;
                            }
                            
                            
                        }

                    }
                    
                }
                
            }
            
        }
        
    }
    

    return 0;
}