#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

void csere(char *a, char *b)
{
    char pillanat = *a;
    *a = *b;
    *b = pillanat;
}

void my_strfry(char *s)
{
    int n = strlen(s);
    srand(time(NULL));
    for (int i = 0; i < n - 1; i++)
    {
        int j = i + rand() % (n - i);
        csere(&s[i], &s[j]);
    }
}

int main()
{
    char s[] = "Hello World!";
    my_strfry(s);
    printf("%s\n", s);

    return 0;
}