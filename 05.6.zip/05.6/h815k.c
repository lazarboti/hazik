#include <stdio.h>

void nyitas(int tomb[], int lepes)
{
    for (int i = 1; i <= 600; i + lepes)
    {
        if (tomb[i] == 1)
        {
            tomb[i] = 0;
        }
        else
        {
            tomb[i] = 1;
        }
    }
}
int main()
{

    int tomb[601] = {0};
    nyitas(tomb, 1);
    nyitas(tomb, 2);
    nyitas(tomb, 3);
    nyitas(tomb, 4);
    nyitas(tomb, 5);
    nyitas(tomb, 6);
    nyitas(tomb, 7);
    nyitas(tomb, 8);
    for (int i = 1; i <= 600; i++)
    {
        if (tomb[i] == 1)
        {
            printf("%d", i);
        }
    }
    puts("");

    return 0;
}
