#include <stdio.h>
#include <stdlib.h>

int compare(const void *a, const void *b)
{
    return (*(int *)a - *(int *)b);
}

int main()
{
    FILE *file = fopen("numbers.txt", "r");
    if (file == NULL)
    {
        printf("Hiba a fajl megnyitasakor!");
        return 1;
    }

    int *szamok = NULL;
    int hossz = 100; 
    int elemszam = 0;     

    if (szamok == NULL)
    {
        printf("Memoriafoglalasi hiba!");
        return 1;
    }

    int number;
    while (fscanf(file, "%d", &number) != EOF)
    {

        if (elemszam >= hossz)
        {
            hossz *= 2;
            szamok = realloc(szamok, hossz * sizeof(int));
            if (szamok == NULL)
            {
                printf("Memoriafoglalasi hiba!");
                return 1;
            }
        }
        szamok[elemszam++] = number;
    }

    fclose(file);

    qsort(szamok, elemszam, sizeof(int), compare);

    printf("Rendezett szamok:\n");
    for (int i = 0; i < elemszam; i++)
    {
        printf("%d ", szamok[i]);
    }
    printf("\n");
    free(szamok);

    return 0;
}